package me.emirhan.turkishai;

import com.google.gson.*;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class TurkishAI extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Set<UUID> aiMode = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Deque<JsonObject>> histories = new ConcurrentHashMap<>();
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    private Semaphore requests;
    private HttpClient http;
    private final Gson gson = new Gson();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        requests = new Semaphore(3);
        http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();

        Objects.requireNonNull(getCommand("ai")).setExecutor(this);
        Objects.requireNonNull(getCommand("ai")).setTabCompleter(this);
        Objects.requireNonNull(getCommand("apiai")).setExecutor(this);

        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("TurkishAI aktif.");
    }

    @Override
    public void onDisable() {
        aiMode.clear();
        histories.clear();
        cooldowns.clear();
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        if (!aiMode.contains(player.getUniqueId())) return;

        String message = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        if (message.isEmpty()) return;

        event.setCancelled(true);

        int max = getConfig().getInt("ai.max-message-length", 500);
        if (message.length() > max) {
            player.sendMessage(Component.text(ChatColor.RED + "[AI] Mesaj en fazla " + max + " karakter olabilir."));
            return;
        }

        String key = getConfig().getString("groq.api-key", "").trim();
        if (key.isEmpty()) {
            player.sendMessage(Component.text(ChatColor.RED + "[AI] API anahtarı ayarlanmamış. Yönetici /apiai <API_KEY> kullanmalı."));
            return;
        }

        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("ai.cooldown-seconds", 3) * 1000L;
        Long last = cooldowns.get(player.getUniqueId());
        if (last != null && now - last < cd) {
            long left = Math.max(1, (cd - (now - last) + 999) / 1000);
            player.sendMessage(Component.text(ChatColor.YELLOW + "[AI] " + left + " saniye bekle."));
            return;
        }
        cooldowns.put(player.getUniqueId(), now);

        if (!requests.tryAcquire()) {
            player.sendMessage(Component.text(ChatColor.YELLOW + "[AI] Şu anda çok fazla istek var, biraz bekle."));
            return;
        }

        Deque<JsonObject> history = histories.computeIfAbsent(player.getUniqueId(), k -> new ArrayDeque<>());
        int maxHistory = Math.max(2, getConfig().getInt("ai.max-history", 12));

        synchronized (history) {
            JsonObject user = new JsonObject();
            user.addProperty("role", "user");
            user.addProperty("content", message);
            history.addLast(user);
            while (history.size() > maxHistory) history.removeFirst();
        }

        player.sendMessage(Component.text(ChatColor.GRAY + "[AI] Düşünüyor..."));

        CompletableFuture.runAsync(() -> {
            try {
                String answer = askGroq(key, player.getUniqueId(), message);
                Bukkit.getScheduler().runTask(this, () -> {
                    if (player.isOnline()) {
                        player.sendMessage(Component.text(ChatColor.AQUA + "[AI] " + answer));
                    }
                });
            } catch (Exception ex) {
                getLogger().warning("Groq isteği başarısız: " + ex.getClass().getSimpleName());
                Bukkit.getScheduler().runTask(this, () -> {
                    if (player.isOnline()) {
                        player.sendMessage(Component.text(ChatColor.RED + "[AI] Şu anda AI hizmetine ulaşılamıyor."));
                    }
                });
                removeLastUserMessage(player.getUniqueId());
            } finally {
                requests.release();
            }
        });
    }

    private String askGroq(String key, UUID uuid, String newMessage) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", getConfig().getString("groq.model", "llama-3.3-70b-versatile"));
        body.addProperty("temperature", getConfig().getDouble("groq.temperature", 0.5));
        body.addProperty("max_tokens", getConfig().getInt("groq.max-tokens", 300));

        JsonArray messages = new JsonArray();
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content", getConfig().getString("system-prompt"));
        messages.add(system);

        Deque<JsonObject> history = histories.get(uuid);
        if (history != null) {
            synchronized (history) {
                for (JsonObject item : history) messages.add(item.deepCopy());
            }
        }
        body.add("messages", messages);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.groq.com/openai/v1/chat/completions"))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + key)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(body)))
                .build();

        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IOException("HTTP " + response.statusCode());
        }

        JsonObject root = JsonParser.parseString(response.body()).getAsJsonObject();
        JsonArray choices = root.getAsJsonArray("choices");
        if (choices == null || choices.isEmpty()) throw new IOException("choices yok");

        String answer = choices.get(0).getAsJsonObject()
                .getAsJsonObject("message")
                .get("content").getAsString().trim();

        JsonObject assistant = new JsonObject();
        assistant.addProperty("role", "assistant");
        assistant.addProperty("content", answer);

        if (history != null) {
            synchronized (history) {
                history.addLast(assistant);
                int max = Math.max(2, getConfig().getInt("ai.max-history", 12));
                while (history.size() > max) history.removeFirst();
            }
        }
        return answer;
    }

    private void removeLastUserMessage(UUID uuid) {
        Deque<JsonObject> history = histories.get(uuid);
        if (history == null) return;
        synchronized (history) {
            if (!history.isEmpty()) history.removeLast();
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("ai")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Bu komut sadece oyuncular içindir.");
                return true;
            }
            UUID id = player.getUniqueId();
            if (!aiMode.add(id)) {
                aiMode.remove(id);
                histories.remove(id);
                player.sendMessage(Component.text(ChatColor.YELLOW + "[AI] AI sohbet modu kapatıldı."));
            } else {
                player.sendMessage(Component.text(ChatColor.GREEN + "[AI] AI sohbet modu açıldı. Chat'e mesaj yazabilirsin."));
            }
            return true;
        }

        if (command.getName().equalsIgnoreCase("apiai")) {
            if (!sender.hasPermission("turkishai.admin")) {
                sender.sendMessage(ChatColor.RED + "Bu komut için yetkin yok.");
                return true;
            }
            if (args.length != 1 || args[0].isBlank()) {
                sender.sendMessage(ChatColor.YELLOW + "Kullanım: /apiai <GROQ_API_KEY>");
                return true;
            }
            getConfig().set("groq.api-key", args[0]);
            saveConfig();
            sender.sendMessage(ChatColor.GREEN + "Groq API anahtarı kaydedildi.");
            return true;
        }
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return Collections.emptyList();
    }
}
