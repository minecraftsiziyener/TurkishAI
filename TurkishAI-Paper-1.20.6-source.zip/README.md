# TurkishAI — Paper 1.20.6

Gereksinimler:
- Paper 1.20.6
- Java 21
- Groq API key

Derleme:
mvn clean package

Jar:
target/TurkishAI-1.0.0.jar

Kurulum:
1. Jar'ı Aternos sunucusunun plugins bölümüne yükle.
2. Sunucuyu yeniden başlat.
3. OP olan yönetici olarak /apiai GSK_API_KEY yaz.
4. /ai ile AI modunu aç/kapat.
5. AI modu açıkken normal chat mesajların Groq'a gönderilir.

Not: API anahtarını kimseyle paylaşma. /apiai komutunu yalnızca OP kullanabilir.
